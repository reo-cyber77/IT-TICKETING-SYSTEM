namespace TicketDesk;

public sealed class Ticket
{
    public int Id { get; set; }
    public string Title { get; set; } = "";
    public string Category { get; set; } = "General";
    public string Priority { get; set; } = "Medium";
    public string Status { get; set; } = "Open";
    public string Requester { get; set; } = "";
    public string AssignedTo { get; set; } = "Unassigned";
    public string Description { get; set; } = "";
    public DateTime CreatedAt { get; set; } = DateTime.Now;
}
