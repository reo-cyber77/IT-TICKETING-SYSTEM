namespace TicketDesk;

public sealed class LoginForm : Form
{
    private string role = "Employee";
    private readonly TextBox nameBox = new();
    private readonly TextBox passwordBox = new();
    private readonly TextBox confirmBox = new();
    private readonly ComboBox departmentBox = new();
    private readonly Label formMode = new();
    private readonly Label nameLabel = new();
    private readonly Label passwordLabel = new();
    private readonly Label confirmLabel = new();
    private readonly Label departmentLabel = new();
    private readonly Button employeeButton = new();
    private readonly Button supportButton = new();
    private readonly Button submitButton = new();
    private readonly LinkLabel toggleMode = new();
    private bool creatingAccount;

    public LoginForm()
    {
        Text = "Northstar IT · Sign in"; Size = new Size(980, 700); MinimumSize = new Size(820, 650);
        StartPosition = FormStartPosition.CenterScreen; BackColor = Color.FromArgb(246, 248, 252); Font = new Font("Segoe UI", 10);
        var split = new SplitContainer { Dock = DockStyle.Fill, FixedPanel = FixedPanel.Panel1, IsSplitterFixed = true, BackColor = Color.White };
        Controls.Add(split);
        var brand = new Panel { Dock = DockStyle.Fill, BackColor = Color.FromArgb(232, 240, 253) }; split.Panel1.Controls.Add(brand);
        var logo = new Label { Text = "✦  NORTHSTAR", ForeColor = Color.FromArgb(25, 42, 74), Font = new Font("Segoe UI Semibold", 14), Location = new Point(44, 38), AutoSize = true }; brand.Controls.Add(logo);
        var hero = new Label { Text = "IT support,\nwithout the\nrunaround.", ForeColor = Color.FromArgb(25, 42, 74), Font = new Font("Segoe UI Semibold", 31), Location = new Point(44, 160), AutoSize = true }; brand.Controls.Add(hero);
        var desc = new Label { Text = "One place to report issues, track progress,\nand get back to what matters.", ForeColor = Color.FromArgb(66, 84, 112), Font = new Font("Segoe UI", 11), Location = new Point(48, 330), AutoSize = true }; brand.Controls.Add(desc);
        var right = new Panel { Dock = DockStyle.Fill, Padding = new Padding(54, 56, 54, 30) }; split.Panel2.Controls.Add(right);
        var title = new Label { Text = "Welcome back", Font = new Font("Segoe UI Semibold", 25), ForeColor = Color.FromArgb(25, 42, 74), AutoSize = true, Location = new Point(48, 55) }; right.Controls.Add(title);
        var sub = new Label { Text = "Choose your workspace to continue.", ForeColor = Color.FromArgb(111, 123, 142), AutoSize = true, Location = new Point(50, 102) }; right.Controls.Add(sub);
        right.Controls.Add(new Label { Text = "SIGN IN AS", ForeColor = Color.FromArgb(90, 105, 127), Font = new Font("Segoe UI Semibold", 9), Location = new Point(50, 160), AutoSize = true });
        employeeButton.Text = "Employee"; supportButton.Text = "IT Support";
        StyleRole(employeeButton, new Point(50, 188)); StyleRole(supportButton, new Point(224, 188)); right.Controls.Add(employeeButton); right.Controls.Add(supportButton);
        employeeButton.Click += (_, _) => SetRole("Employee"); supportButton.Click += (_, _) => SetRole("IT Support");
        formMode.Text = "SIGN IN"; formMode.ForeColor = Color.FromArgb(90, 105, 127); formMode.Font = new Font("Segoe UI Semibold", 9); formMode.Location = new Point(50, 260); formMode.AutoSize = true; right.Controls.Add(formMode);
        nameLabel.Text = "USERNAME"; nameLabel.ForeColor = Color.FromArgb(90, 105, 127); nameLabel.Font = new Font("Segoe UI Semibold", 8); nameLabel.Location = new Point(50, 286); nameLabel.AutoSize = true; right.Controls.Add(nameLabel);
        nameBox.SetBounds(50, 308, 348, 38); nameBox.Font = new Font("Segoe UI", 10); nameBox.BorderStyle = BorderStyle.FixedSingle; right.Controls.Add(nameBox);
        passwordLabel.Text = "PASSWORD"; passwordLabel.ForeColor = Color.FromArgb(90, 105, 127); passwordLabel.Font = new Font("Segoe UI Semibold", 8); passwordLabel.SetBounds(50, 357, 348, 18); right.Controls.Add(passwordLabel);
        passwordBox.SetBounds(50, 378, 348, 38); passwordBox.Font = new Font("Segoe UI", 10); passwordBox.UseSystemPasswordChar = true; passwordBox.BorderStyle = BorderStyle.FixedSingle; right.Controls.Add(passwordBox);
        confirmLabel.Text = "CONFIRM PASSWORD"; confirmLabel.ForeColor = Color.FromArgb(90, 105, 127); confirmLabel.Font = new Font("Segoe UI Semibold", 8); confirmLabel.SetBounds(50, 423, 348, 18); right.Controls.Add(confirmLabel);
        confirmBox.SetBounds(50, 444, 348, 38); confirmBox.Font = new Font("Segoe UI", 10); confirmBox.UseSystemPasswordChar = true; confirmBox.BorderStyle = BorderStyle.FixedSingle; right.Controls.Add(confirmBox);
        departmentLabel.Text = "DEPARTMENT"; departmentLabel.ForeColor = Color.FromArgb(90, 105, 127); departmentLabel.Font = new Font("Segoe UI Semibold", 8); departmentLabel.SetBounds(50, 489, 348, 18); right.Controls.Add(departmentLabel);
        departmentBox.SetBounds(50, 510, 348, 36); departmentBox.DropDownStyle = ComboBoxStyle.DropDownList; departmentBox.Font = new Font("Segoe UI", 10); departmentBox.Items.AddRange(["Administration", "Finance", "Human Resources", "IT", "Marketing", "Operations", "Sales", "Other"]); departmentBox.SelectedIndex = 0; right.Controls.Add(departmentBox);
        submitButton.Text = "Continue to dashboard   →"; submitButton.SetBounds(50, 558, 348, 42); submitButton.BackColor = Color.FromArgb(46, 111, 225); submitButton.ForeColor = Color.White; submitButton.FlatStyle = FlatStyle.Flat; submitButton.Font = new Font("Segoe UI Semibold", 10); submitButton.Cursor = Cursors.Hand; submitButton.FlatAppearance.BorderSize = 0; right.Controls.Add(submitButton);
        toggleMode.Text = "Create an employee account"; toggleMode.SetBounds(50, 606, 348, 20); toggleMode.LinkColor = Color.FromArgb(46, 111, 225); right.Controls.Add(toggleMode);
        submitButton.Click += (_, _) => Submit(); toggleMode.Click += (_, _) => SetCreateMode(!creatingAccount);
        SetCreateMode(false);
        SetRole("Employee");
        Shown += (_, _) =>
        {
            split.Panel1MinSize = 340;
            split.Panel2MinSize = 420;
            SetLoginPanelWidths(split);
        };
        Resize += (_, _) => SetLoginPanelWidths(split);
    }

    private void SetLoginPanelWidths(SplitContainer split)
    {
        if (split.Width <= 0) return;
        var desired = (int)(split.Width * 0.43);
        var max = split.Width - split.Panel2MinSize - split.SplitterWidth;
        var min = split.Panel1MinSize;
        if (max >= min) split.SplitterDistance = Math.Clamp(desired, min, max);
    }

    private void StyleRole(Button b, Point p) { b.SetBounds(p.X, p.Y, 164, 52); b.FlatStyle = FlatStyle.Flat; b.Font = new Font("Segoe UI Semibold", 10); b.Cursor = Cursors.Hand; }
    private void SetRole(string value)
    {
        role = value;
        foreach (var (button, selected) in new[] { (employeeButton, value == "Employee"), (supportButton, value == "IT Support") })
        { button.BackColor = selected ? Color.FromArgb(234, 241, 255) : Color.White; button.ForeColor = selected ? Color.FromArgb(46, 111, 225) : Color.FromArgb(64, 76, 96); button.FlatAppearance.BorderColor = selected ? Color.FromArgb(46, 111, 225) : Color.FromArgb(220, 225, 233); }
        if (value == "IT Support") SetCreateMode(false);
        toggleMode.Visible = value == "Employee";
        toggleMode.Text = value == "Employee" ? "Create an employee account" : "Create an IT Support account";
        nameBox.Clear();
        passwordBox.Clear();
    }
    private void SetCreateMode(bool create)
    {
        creatingAccount = create;
        formMode.Text = create ? role == "Employee" ? "CREATE EMPLOYEE ACCOUNT" : "CREATE IT SUPPORT ACCOUNT" : "SIGN IN";
        confirmLabel.Visible = confirmBox.Visible = create;
        departmentLabel.Visible = departmentBox.Visible = create && role == "Employee";
        passwordLabel.Visible = passwordBox.Visible = true;
        submitButton.Text = create ? "Create account   →" : "Continue to dashboard   →";
        toggleMode.Text = create ? "Already have an account? Sign in" : role == "Employee" ? "Create an employee account" : "Create an IT Support account";
        toggleMode.Visible = role == "Employee";
        nameBox.SetBounds(50, create ? 286 : 308, 348, 38);
        nameLabel.Top = create ? 264 : 286;
        passwordLabel.Top = create ? 335 : 357; passwordBox.Top = create ? 356 : 378;
        confirmLabel.Top = 401; confirmBox.Top = 422; departmentLabel.Top = 467; departmentBox.Top = 488;
        submitButton.Top = create ? role == "Employee" ? 536 : 474 : 444; toggleMode.Top = create ? role == "Employee" ? 582 : 520 : 493;
    }
    private void Submit()
    {
        if (string.IsNullOrWhiteSpace(nameBox.Text)) { MessageBox.Show("Enter your full name.", "Name required"); return; }
        if (creatingAccount)
        {
            if (role != "Employee") { MessageBox.Show("IT Support accounts are managed in support_accounts.txt.", "Account setup"); return; }
            if (passwordBox.Text.Length < 6) { MessageBox.Show("Choose a password with at least 6 characters.", "Password too short"); return; }
            if (passwordBox.Text != confirmBox.Text) { MessageBox.Show("The passwords do not match.", "Check password"); return; }
            var accountDepartment = role == "Employee" ? departmentBox.Text : "";
            if (!AccountStore.Create(nameBox.Text.Trim(), accountDepartment, passwordBox.Text, role)) { MessageBox.Show("An account with that username already exists for this role. Please sign in instead.", "Account exists"); return; }
            SystemHistory.Log($"Employee account created: {nameBox.Text.Trim()} (department: {accountDepartment}).");
            OpenApp(nameBox.Text.Trim(), role, accountDepartment); return;
        }
        if (!AccountStore.Verify(nameBox.Text, passwordBox.Text, role))
        {
            SystemHistory.Log($"Sign-in failed for {role}, username: {nameBox.Text.Trim()}.");
            MessageBox.Show("Username or password is incorrect.", "Sign-in failed"); return;
        }
        var account = AccountStore.Find(nameBox.Text, role)!;
        SystemHistory.Log($"Successful sign-in: {account.Username} ({role}).");
        OpenApp(account.Name, role, account.Department);
    }
    private void OpenApp(string name, string selectedRole, string department)
    {
        Hide();
        bool loggedOut;
        using (var app = new MainForm(name, selectedRole, department))
        {
            app.ShowDialog();
            loggedOut = app.LoggedOut;
        }
        if (loggedOut)
        {
            SetCreateMode(false); SetRole("Employee"); nameBox.Clear(); passwordBox.Clear(); confirmBox.Clear(); Show(); Activate(); return;
        }
        Close();
    }
}
