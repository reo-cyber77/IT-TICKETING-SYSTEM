using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace TicketDesk;

public sealed class EmployeeAccount
{
    public string Name { get; set; } = "";
    public string Username { get; set; } = "";
    public string Department { get; set; } = "";
    public string PasswordHash { get; set; } = "";
    public string Role { get; set; } = "Employee";
}

public static class AccountStore
{
    private static readonly string ProjectDirectory = FindProjectDirectory();
    private static readonly string FilePath = Path.Combine(ProjectDirectory, "employees.json");
    private static readonly string CredentialsPath = Path.Combine(ProjectDirectory, "login_credentials.txt");
    private static readonly string SupportAccountsPath = Path.Combine(ProjectDirectory, "support_accounts.txt");
    private static List<EmployeeAccount> accounts = Load();
    static AccountStore()
    {
        EnsureSupportAccountsFile();
        accounts.RemoveAll(a => a.Role == "IT Support");
        LoadSupportAccounts();
        SaveAccounts();
        if (!File.Exists(CredentialsPath)) WriteCredentialsFile();
    }

    public static string CredentialsFile => CredentialsPath;

    private static string FindProjectDirectory()
    {
        var current = new DirectoryInfo(AppContext.BaseDirectory);
        while (current != null)
        {
            if (File.Exists(Path.Combine(current.FullName, "TicketDesk.csproj"))) return current.FullName;
            current = current.Parent;
        }
        return AppContext.BaseDirectory;
    }
    private static List<EmployeeAccount> Load()
    {
        try { if (File.Exists(FilePath)) return JsonSerializer.Deserialize<List<EmployeeAccount>>(File.ReadAllText(FilePath)) ?? []; } catch { }
        return [];
    }
    public static EmployeeAccount? Find(string username, string role) => accounts.FirstOrDefault(a => (string.IsNullOrEmpty(a.Username) ? a.Name : a.Username).Equals(username.Trim(), StringComparison.OrdinalIgnoreCase) && a.Role == role);
    public static bool Verify(string username, string password, string role)
    {
        if (role == "IT Support") ReloadSupportAccounts();
        if (role == "Employee" && !EmployeeCredentialsAreActive(username, password)) return false;
        var account = Find(username, role);
        if (account == null) return false;
        try { return CryptographicOperations.FixedTimeEquals(Convert.FromHexString(account.PasswordHash), SHA256.HashData(Encoding.UTF8.GetBytes(password))); }
        catch (FormatException) { return false; }
    }
    private static bool EmployeeCredentialsAreActive(string username, string password)
    {
        if (!File.Exists(CredentialsPath)) return false;
        string? listedUsername = null;
        string? listedPassword = null;
        var inEmployeeBlock = false;
        var isActive = false;

        void CheckBlock()
        {
            if (inEmployeeBlock && listedUsername != null && listedPassword != null &&
                listedUsername.Equals(username.Trim(), StringComparison.OrdinalIgnoreCase) &&
                listedPassword.Equals(password, StringComparison.Ordinal)) isActive = true;
        }

        foreach (var rawLine in File.ReadLines(CredentialsPath))
        {
            var line = rawLine.Trim();
            if (line.Equals("EMPLOYEE", StringComparison.OrdinalIgnoreCase) || line.Equals("EMPLOYEE ACCOUNT", StringComparison.OrdinalIgnoreCase))
            {
                CheckBlock();
                inEmployeeBlock = true;
                listedUsername = listedPassword = null;
                continue;
            }
            if (line.Equals("IT SUPPORT", StringComparison.OrdinalIgnoreCase) || line.Equals("IT SUPPORT ACCOUNT", StringComparison.OrdinalIgnoreCase))
            {
                CheckBlock();
                inEmployeeBlock = false;
                listedUsername = listedPassword = null;
                continue;
            }
            if (!inEmployeeBlock) continue;
            if (line.StartsWith("Username:", StringComparison.OrdinalIgnoreCase)) listedUsername = line["Username:".Length..].Trim();
            else if (line.StartsWith("Password:", StringComparison.OrdinalIgnoreCase)) listedPassword = line["Password:".Length..].Trim();
        }
        CheckBlock();
        return isActive;
    }
    public static bool Create(string name, string department, string password)
        => Create(name, department, password, "Employee");

    public static bool Create(string name, string department, string password, string role)
    {
        if (role != "Employee") return false;
        if (accounts.Any(a => (string.IsNullOrEmpty(a.Username) ? a.Name : a.Username).Equals(name.Trim(), StringComparison.OrdinalIgnoreCase) && a.Role == role)) return false;
        var account = new EmployeeAccount { Name = name.Trim(), Username = name.Trim(), Department = department, Role = role, PasswordHash = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(password))) };
        accounts.Add(account);
        SaveAccounts();
        AppendCredential(account, password);
        return true;
    }

    private static void EnsureSupportAccountsFile()
    {
        if (!File.Exists(SupportAccountsPath))
            File.WriteAllText(SupportAccountsPath,
                "# IT SUPPORT LOGIN ACCOUNTS\r\n" +
                "# Add one account per line in this format: username|password|display name\r\n" +
                "# There are no default accounts. Add your own accounts below.\r\n");
    }
    private static void LoadSupportAccounts()
    {
        foreach (var line in File.ReadLines(SupportAccountsPath))
        {
            var entry = line.Trim();
            if (entry.Length == 0 || entry.StartsWith('#')) continue;
            var fields = entry.Split('|', 3);
            if (fields.Length < 2 || string.IsNullOrWhiteSpace(fields[0]) || string.IsNullOrWhiteSpace(fields[1])) continue;
            var username = fields[0].Trim();
            var password = fields[1].Trim();
            var displayName = fields.Length == 3 && !string.IsNullOrWhiteSpace(fields[2]) ? fields[2].Trim() : username;
            if (accounts.Any(a => a.Role == "IT Support" && (string.IsNullOrEmpty(a.Username) ? a.Name : a.Username).Equals(username, StringComparison.OrdinalIgnoreCase))) continue;
            accounts.Add(new EmployeeAccount
            {
                Name = displayName,
                Username = username,
                Role = "IT Support",
                PasswordHash = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(password)))
            });
        }
    }
    private static void ReloadSupportAccounts()
    {
        if (!File.Exists(SupportAccountsPath)) return;
        accounts.RemoveAll(a => a.Role == "IT Support");
        LoadSupportAccounts();
    }
    private static void SaveAccounts() => File.WriteAllText(FilePath, JsonSerializer.Serialize(accounts, new JsonSerializerOptions { WriteIndented = true }));
    private static void WriteCredentialsFile()
    {
        File.WriteAllText(CredentialsPath, "NORTHSTAR IT TICKETING SYSTEM — EMPLOYEE LOGIN ACCESS LIST\r\n" +
            "There are no default employee accounts. Create accounts from the Employee sign-in screen.\r\n" +
            "Employee accounts must be listed below to sign in. Remove an employee's block to revoke access.\r\n");
    }
    private static void AppendCredential(EmployeeAccount account, string password)
    {
        if (!File.Exists(CredentialsPath)) WriteCredentialsFile();
        var section = account.Role == "IT Support" ? "IT SUPPORT ACCOUNT" : "EMPLOYEE ACCOUNT";
        var departmentLine = string.IsNullOrWhiteSpace(account.Department) ? "" : $"Department: {account.Department}\r\n";
        File.AppendAllText(CredentialsPath, $"\r\n{section}\r\nUsername: {account.Username}\r\nPassword: {password}\r\n{departmentLine}");
    }
}
