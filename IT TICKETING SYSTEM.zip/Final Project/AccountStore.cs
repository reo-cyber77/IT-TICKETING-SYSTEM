using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace TicketDesk;

public sealed class EmployeeAccount
{
    public string Name { get; set; } = "";
    public string Username { get; set; } = "";
    public string Department { get; set; } = "";
    public string PasswordHash { get; set; } = "";
    public string Role { get; set; } = "Employee";
}

public static class AccountStore
{
    private static readonly string ProjectDirectory = FindProjectDirectory();
    private static readonly string FilePath = Path.Combine(ProjectDirectory, "employees.json");
    private static readonly string CredentialsPath = Path.Combine(ProjectDirectory, "login_credentials.txt");
    private static readonly string SupportAccountsPath = Path.Combine(ProjectDirectory, "support_accounts.txt");
    private static List<EmployeeAccount> accounts = Load();
    static AccountStore()
    {
        AddDemoAccount("employee", "Alex Morgan", "Administration", "Employee123!", "Employee");
        EnsureSupportAccountsFile();
        accounts.RemoveAll(a => a.Role == "IT Support");
        LoadSupportAccounts();
        SaveAccounts();
        if (!File.Exists(CredentialsPath)) WriteCredentialsFile();
    }

    public static string CredentialsFile => CredentialsPath;

    private static string FindProjectDirectory()
    {
        var current = new DirectoryInfo(AppContext.BaseDirectory);
        while (current != null)
        {
            if (File.Exists(Path.Combine(current.FullName, "TicketDesk.csproj"))) return current.FullName;
            current = current.Parent;
        }
        return AppContext.BaseDirectory;
    }
    private static List<EmployeeAccount> Load()
    {
        try { if (File.Exists(FilePath)) return JsonSerializer.Deserialize<List<EmployeeAccount>>(File.ReadAllText(FilePath)) ?? []; } catch { }
        return [];
    }
    public static EmployeeAccount? Find(string username, string role) => accounts.FirstOrDefault(a => (string.IsNullOrEmpty(a.Username) ? a.Name : a.Username).Equals(username.Trim(), StringComparison.OrdinalIgnoreCase) && a.Role == role);
    public static bool Verify(string username, string password, string role)
    {
        if (role == "IT Support") ReloadSupportAccounts();
        var account = Find(username, role);
        if (account == null) return false;
        try { return CryptographicOperations.FixedTimeEquals(Convert.FromHexString(account.PasswordHash), SHA256.HashData(Encoding.UTF8.GetBytes(password))); }
        catch (FormatException) { return false; }
    }
    public static bool Create(string name, string department, string password)
        => Create(name, department, password, "Employee");

    public static bool Create(string name, string department, string password, string role)
    {
        if (role != "Employee") return false;
        if (accounts.Any(a => (string.IsNullOrEmpty(a.Username) ? a.Name : a.Username).Equals(name.Trim(), StringComparison.OrdinalIgnoreCase) && a.Role == role)) return false;
        var account = new EmployeeAccount { Name = name.Trim(), Username = name.Trim(), Department = department, Role = role, PasswordHash = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(password))) };
        accounts.Add(account);
        SaveAccounts();
        AppendCredential(account, password);
        return true;
    }

    private static void AddDemoAccount(string username, string displayName, string department, string password, string role)
    {
        if (Find(username, role) != null) return;
        accounts.Add(new EmployeeAccount { Name = displayName, Username = username, Department = department, Role = role, PasswordHash = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(password))) });
    }
    private static void EnsureSupportAccountsFile()
    {
        if (!File.Exists(SupportAccountsPath))
            File.WriteAllText(SupportAccountsPath,
                "# IT SUPPORT LOGIN ACCOUNTS\r\n" +
                "# Add one account per line in this format: username|password|display name\r\n" +
                "# Example: technician1|ChangeMe123!|Jordan Lee\r\n" +
                "# Restart the app after editing this file.\r\n\r\n" +
                "support|Support123!|Jordan Lee\r\n");
    }
    private static void LoadSupportAccounts()
    {
        foreach (var line in File.ReadLines(SupportAccountsPath))
        {
            var entry = line.Trim();
            if (entry.Length == 0 || entry.StartsWith('#')) continue;
            var fields = entry.Split('|', 3);
            if (fields.Length < 2 || string.IsNullOrWhiteSpace(fields[0]) || string.IsNullOrWhiteSpace(fields[1])) continue;
            var username = fields[0].Trim();
            var password = fields[1].Trim();
            var displayName = fields.Length == 3 && !string.IsNullOrWhiteSpace(fields[2]) ? fields[2].Trim() : username;
            if (accounts.Any(a => a.Role == "IT Support" && (string.IsNullOrEmpty(a.Username) ? a.Name : a.Username).Equals(username, StringComparison.OrdinalIgnoreCase))) continue;
            accounts.Add(new EmployeeAccount
            {
                Name = displayName,
                Username = username,
                Role = "IT Support",
                PasswordHash = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(password)))
            });
        }
    }
    private static void ReloadSupportAccounts()
    {
        if (!File.Exists(SupportAccountsPath)) return;
        accounts.RemoveAll(a => a.Role == "IT Support");
        LoadSupportAccounts();
    }
    private static void SaveAccounts() => File.WriteAllText(FilePath, JsonSerializer.Serialize(accounts, new JsonSerializerOptions { WriteIndented = true }));
    private static void WriteCredentialsFile()
    {
        File.WriteAllText(CredentialsPath, "NORTHSTAR IT TICKETING SYSTEM — DEMO LOGIN CREDENTIALS\r\n" +
            "For this local school project only. Do not use these passwords for real accounts.\r\n\r\n" +
            "EMPLOYEE\r\nUsername: employee\r\nPassword: Employee123!\r\nDepartment: Administration\r\n\r\n" +
            "IT SUPPORT\r\nUsername: support\r\nPassword: Support123!\r\n\r\n" +
            "New employee account credentials are added to this file when the account is created.\r\n");
    }
    private static void AppendCredential(EmployeeAccount account, string password)
    {
        if (!File.Exists(CredentialsPath)) WriteCredentialsFile();
        var section = account.Role == "IT Support" ? "IT SUPPORT ACCOUNT" : "EMPLOYEE ACCOUNT";
        var departmentLine = string.IsNullOrWhiteSpace(account.Department) ? "" : $"Department: {account.Department}\r\n";
        File.AppendAllText(CredentialsPath, $"\r\n{section}\r\nUsername: {account.Username}\r\nPassword: {password}\r\n{departmentLine}");
    }
}
