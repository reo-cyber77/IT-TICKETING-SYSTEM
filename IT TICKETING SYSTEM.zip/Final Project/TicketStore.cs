using System.Text.Json;

namespace TicketDesk;

public static class TicketStore
{
    private static readonly string ProjectDirectory = FindProjectDirectory();
    private static readonly string FilePath = Path.Combine(ProjectDirectory, "tickets.json");
    private static readonly string TextFilePath = Path.Combine(ProjectDirectory, "tickets.txt");
    private static readonly string LegacyFilePath = Path.Combine(AppContext.BaseDirectory, "tickets.json");
    public static List<Ticket> Tickets { get; private set; } = Load();
    static TicketStore() => Save();

    public static void Save()
    {
        File.WriteAllText(FilePath, JsonSerializer.Serialize(Tickets, new JsonSerializerOptions { WriteIndented = true }));
        var report = new System.Text.StringBuilder();
        report.AppendLine("NORTHSTAR IT TICKETING SYSTEM — CURRENT TICKETS");
        report.AppendLine($"Last updated: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
        report.AppendLine($"Active ticket count: {Tickets.Count}");
        report.AppendLine(new string('=', 72));
        foreach (var ticket in Tickets.OrderBy(t => t.Id))
        {
            report.AppendLine($"Ticket: #{ticket.Id}");
            report.AppendLine($"Title: {ticket.Title}");
            report.AppendLine($"Category: {ticket.Category}");
            report.AppendLine($"Priority: {ticket.Priority}");
            report.AppendLine($"Status: {ticket.Status}");
            report.AppendLine($"Requester: {ticket.Requester}");
            report.AppendLine($"Assigned to: {ticket.AssignedTo}");
            report.AppendLine($"Created: {ticket.CreatedAt:yyyy-MM-dd HH:mm}");
            report.AppendLine($"Description: {ticket.Description.Replace("\r", " ").Replace("\n", " ")}");
            report.AppendLine(new string('-', 72));
        }
        File.WriteAllText(TextFilePath, report.ToString());
    }

    private static string FindProjectDirectory()
    {
        var current = new DirectoryInfo(AppContext.BaseDirectory);
        while (current != null)
        {
            if (File.Exists(Path.Combine(current.FullName, "TicketDesk.csproj"))) return current.FullName;
            current = current.Parent;
        }
        return AppContext.BaseDirectory;
    }

    private static List<Ticket> Load()
    {
        try
        {
            if (File.Exists(FilePath)) return JsonSerializer.Deserialize<List<Ticket>>(File.ReadAllText(FilePath)) ?? [];
            if (File.Exists(LegacyFilePath)) return JsonSerializer.Deserialize<List<Ticket>>(File.ReadAllText(LegacyFilePath)) ?? [];
        }
        catch { }
        return [
            new Ticket { Id = 1001, Title = "Cannot connect to office Wi-Fi", Category = "Network", Priority = "High", Status = "In Progress", Requester = "Alex Morgan", AssignedTo = "Jordan Lee", Description = "Connection drops every few minutes in the east wing." },
            new Ticket { Id = 1002, Title = "Request access to shared drive", Category = "Access", Priority = "Medium", Status = "Open", Requester = "Taylor Kim", AssignedTo = "Unassigned", Description = "Please grant access to the Finance shared folder." },
            new Ticket { Id = 1003, Title = "Printer on floor 2 is offline", Category = "Hardware", Priority = "Low", Status = "Resolved", Requester = "Sam Rivera", AssignedTo = "Jordan Lee", Description = "The printer is working again after a restart." }
        ];
    }
}
