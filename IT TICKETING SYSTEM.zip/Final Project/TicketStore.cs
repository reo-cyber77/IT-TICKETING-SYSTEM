using System.Text.Json;

namespace TicketDesk;

public static class TicketStore
{
    private static readonly string FilePath = Path.Combine(AppContext.BaseDirectory, "tickets.json");
    public static List<Ticket> Tickets { get; private set; } = Load();
    public static void Save() => File.WriteAllText(FilePath, JsonSerializer.Serialize(Tickets, new JsonSerializerOptions { WriteIndented = true }));

    private static List<Ticket> Load()
    {
        try
        {
            if (File.Exists(FilePath)) return JsonSerializer.Deserialize<List<Ticket>>(File.ReadAllText(FilePath)) ?? [];
        }
        catch { }
        return [
            new Ticket { Id = 1001, Title = "Cannot connect to office Wi-Fi", Category = "Network", Priority = "High", Status = "In Progress", Requester = "Alex Morgan", AssignedTo = "Jordan Lee", Description = "Connection drops every few minutes in the east wing." },
            new Ticket { Id = 1002, Title = "Request access to shared drive", Category = "Access", Priority = "Medium", Status = "Open", Requester = "Taylor Kim", AssignedTo = "Unassigned", Description = "Please grant access to the Finance shared folder." },
            new Ticket { Id = 1003, Title = "Printer on floor 2 is offline", Category = "Hardware", Priority = "Low", Status = "Resolved", Requester = "Sam Rivera", AssignedTo = "Jordan Lee", Description = "The printer is working again after a restart." }
        ];
    }
}
