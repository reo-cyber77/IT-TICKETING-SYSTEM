namespace TicketDesk;

public sealed class HistoryEntry
{
    public string Timestamp { get; set; } = "";
    public string Activity { get; set; } = "";
}

public static class SystemHistory
{
    private static readonly object Sync = new();
    private static readonly string FilePath = Path.Combine(FindProjectDirectory(), "system_history.txt");

    static SystemHistory()
    {
        if (!File.Exists(FilePath))
            File.WriteAllText(FilePath, "NORTHSTAR IT TICKETING SYSTEM — ACTIVITY HISTORY\r\n" +
                "Passwords are never recorded in this file.\r\n\r\n");
    }

    public static void Log(string message)
    {
        var safeMessage = message.Replace('\r', ' ').Replace('\n', ' ').Trim();
        lock (Sync)
        {
            try { File.AppendAllText(FilePath, $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {safeMessage}{Environment.NewLine}"); }
            catch (IOException) { }
            catch (UnauthorizedAccessException) { }
        }
    }

    public static List<HistoryEntry> ReadEntries()
    {
        var entries = new List<HistoryEntry>();
        if (!File.Exists(FilePath)) return entries;
        foreach (var line in File.ReadLines(FilePath))
        {
            if (line.Length < 22 || line[0] != '[') continue;
            var closingBracket = line.IndexOf(']');
            if (closingBracket < 2 || closingBracket + 1 >= line.Length) continue;
            entries.Add(new HistoryEntry
            {
                Timestamp = line[1..closingBracket],
                Activity = line[(closingBracket + 1)..].Trim()
            });
        }
        return entries;
    }

    private static string FindProjectDirectory()
    {
        var current = new DirectoryInfo(AppContext.BaseDirectory);
        while (current != null)
        {
            if (File.Exists(Path.Combine(current.FullName, "TicketDesk.csproj"))) return current.FullName;
            current = current.Parent;
        }
        return AppContext.BaseDirectory;
    }
}
