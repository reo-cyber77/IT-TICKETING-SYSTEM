namespace TicketDesk;

internal static class Program
{
    [STAThread]
    static void Main()
    {
        SystemHistory.Log("Application started.");
        ApplicationConfiguration.Initialize();
        Application.Run(new LoginForm());
    }
}
