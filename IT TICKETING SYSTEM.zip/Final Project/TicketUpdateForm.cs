namespace TicketDesk;

public sealed class TicketUpdateForm : Form
{
    public TicketUpdateForm(Ticket ticket)
    {
        Text = $"Update ticket #{ticket.Id}"; Size = new Size(430, 360); StartPosition = FormStartPosition.CenterParent; FormBorderStyle = FormBorderStyle.FixedDialog; MaximizeBox = false; MinimizeBox = false; BackColor = Color.White; Font = new Font("Segoe UI", 10);
        Controls.Add(new Label { Text = ticket.Title, Location = new Point(24, 22), Size = new Size(360, 48), Font = new Font("Segoe UI Semibold", 12), ForeColor = Color.FromArgb(25, 42, 74) });
        Controls.Add(new Label { Text = "STATUS", Location = new Point(24, 90), AutoSize = true, ForeColor = Color.Gray, Font = new Font("Segoe UI Semibold", 8) });
        var status = new ComboBox { Location = new Point(24, 112), Size = new Size(350, 34), DropDownStyle = ComboBoxStyle.DropDownList }; status.Items.AddRange(["Open", "In Progress", "Resolved"]); status.SelectedItem = ticket.Status; Controls.Add(status);
        Controls.Add(new Label { Text = "ASSIGN TO", Location = new Point(24, 164), AutoSize = true, ForeColor = Color.Gray, Font = new Font("Segoe UI Semibold", 8) });
        var assigned = new TextBox { Location = new Point(24, 186), Size = new Size(350, 34), Text = ticket.AssignedTo, BorderStyle = BorderStyle.FixedSingle }; Controls.Add(assigned);
        var save = new Button { Text = "Save changes", Location = new Point(24, 246), Size = new Size(150, 42), BackColor = Color.FromArgb(46, 111, 225), ForeColor = Color.White, FlatStyle = FlatStyle.Flat }; save.FlatAppearance.BorderSize = 0; Controls.Add(save);
        save.Click += (_, _) => { ticket.Status = status.Text; ticket.AssignedTo = string.IsNullOrWhiteSpace(assigned.Text) ? "Unassigned" : assigned.Text.Trim(); DialogResult = DialogResult.OK; Close(); };
    }
}
