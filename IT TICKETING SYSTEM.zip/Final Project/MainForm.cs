namespace TicketDesk;

public sealed class MainForm : Form
{
    private readonly string userName, role, department;
    private readonly Panel content = new();
    private readonly Label pageTitle = new();
    private readonly DataGridView grid = new();
    private readonly List<Button> navigationButtons = [];
    private string currentPage = "Overview";
    public bool LoggedOut { get; private set; }

    private static readonly Color Navy = Color.FromArgb(25, 42, 74), Blue = Color.FromArgb(31, 82, 190), Muted = Color.FromArgb(101, 115, 136), Bg = Color.FromArgb(246, 248, 252);

    public MainForm(string name, string userRole, string userDepartment = "")
    {
        userName = name; role = userRole; department = userDepartment; Text = "Northstar IT · Ticket Desk"; Size = new Size(1280, 800); MinimumSize = new Size(1050, 680); StartPosition = FormStartPosition.CenterScreen; BackColor = Bg; Font = new Font("Segoe UI", 9.5f);
        BuildShell(); ShowPage("Overview");
    }
    private void BuildShell()
    {
        grid.DataBindingComplete += (_, _) => { grid.ClearSelection(); grid.CurrentCell = null; };
        grid.CellFormatting += FormatTicketCell;
        var sideBg = Color.FromArgb(242, 246, 252);
        var sidebar = new Panel { Dock = DockStyle.Left, Width = 232, BackColor = sideBg }; Controls.Add(sidebar);
        sidebar.Controls.Add(new Label { Text = "✦  NORTHSTAR", ForeColor = Navy, Font = new Font("Segoe UI Semibold", 14), Location = new Point(26, 25), AutoSize = true });
        sidebar.Controls.Add(new Label { Text = "IT SERVICE DESK", ForeColor = Muted, Font = new Font("Segoe UI Semibold", 8), Location = new Point(29, 76), AutoSize = true });
        string[] links = role == "IT Support" ? ["Overview", "All tickets", "Archived tickets", "Activity history", "Knowledge base"] : ["Overview", "My tickets", "New request", "Knowledge base"];
        int y = 108;
        foreach (var link in links) { var b = new Button { Text = "   " + (link switch { "Overview" => "▦", "All tickets" or "My tickets" => "▤", "New request" => "+", _ => "▧" }) + "   " + link, Tag = link, Location = new Point(15, y), Size = new Size(202, 43), FlatStyle = FlatStyle.Flat, TextAlign = ContentAlignment.MiddleLeft, ForeColor = Color.FromArgb(55, 70, 94), BackColor = sideBg, Font = new Font("Segoe UI", 10), Cursor = Cursors.Hand }; b.FlatAppearance.BorderSize = 0; b.FlatAppearance.MouseOverBackColor = Color.FromArgb(229, 237, 249); b.Click += (_, _) => ShowPage((string)b.Tag!); sidebar.Controls.Add(b); navigationButtons.Add(b); y += 48; }
        var profile = new Panel { Dock = DockStyle.Bottom, Height = 74, BackColor = Color.FromArgb(232, 238, 247) }; sidebar.Controls.Add(profile);
        profile.Controls.Add(new Label { Text = userName.Length > 0 ? userName[..1].ToUpper() : "U", Location = new Point(20, 17), Size = new Size(39, 39), TextAlign = ContentAlignment.MiddleCenter, BackColor = Color.FromArgb(213, 228, 250), ForeColor = Blue, Font = new Font("Segoe UI Semibold", 13) });
        profile.Controls.Add(new Label { Text = userName, Location = new Point(70, 15), AutoSize = true, ForeColor = Navy, Font = new Font("Segoe UI Semibold", 9) }); profile.Controls.Add(new Label { Text = string.IsNullOrWhiteSpace(department) ? role : role + " · " + department, Location = new Point(70, 37), AutoSize = true, ForeColor = Muted, Font = new Font("Segoe UI", 8) });
        var main = new Panel { Dock = DockStyle.Fill, BackColor = Bg }; Controls.Add(main); main.BringToFront();
        var top = new Panel { Dock = DockStyle.Top, Height = 75, BackColor = Color.White }; main.Controls.Add(top);
        pageTitle.Text = "Overview"; pageTitle.Font = new Font("Segoe UI Semibold", 16); pageTitle.ForeColor = Navy; pageTitle.Location = new Point(32, 22); pageTitle.AutoSize = true; top.Controls.Add(pageTitle);
        var userBadge = new Panel { Dock = DockStyle.Right, Width = 330, BackColor = Color.White }; top.Controls.Add(userBadge);
        userBadge.Controls.Add(new Label { Text = userName.Length > 0 ? userName[..1].ToUpperInvariant() : "U", Location = new Point(4, 17), Size = new Size(38, 38), TextAlign = ContentAlignment.MiddleCenter, BackColor = Color.FromArgb(234, 241, 255), ForeColor = Blue, Font = new Font("Segoe UI Semibold", 11) });
        userBadge.Controls.Add(new Label { Text = userName, Location = new Point(52, 16), Size = new Size(145, 22), TextAlign = ContentAlignment.MiddleLeft, ForeColor = Navy, Font = new Font("Segoe UI Semibold", 9) });
        userBadge.Controls.Add(new Label { Text = role + (string.IsNullOrWhiteSpace(department) ? "" : " · " + department), Location = new Point(52, 38), Size = new Size(160, 20), TextAlign = ContentAlignment.MiddleLeft, ForeColor = Muted, Font = new Font("Segoe UI", 8) });
        var logout = new Button { Text = "Log out", Location = new Point(221, 19), Size = new Size(83, 34), FlatStyle = FlatStyle.Flat, ForeColor = Color.FromArgb(78, 91, 111), BackColor = Color.FromArgb(246, 248, 252), Font = new Font("Segoe UI Semibold", 8.5f), Cursor = Cursors.Hand, Anchor = AnchorStyles.Top | AnchorStyles.Right };
        logout.FlatAppearance.BorderColor = Color.FromArgb(226, 231, 238); logout.FlatAppearance.MouseOverBackColor = Color.FromArgb(234, 241, 255); userBadge.Controls.Add(logout);
        logout.Click += (_, _) =>
        {
            if (MessageBox.Show("Are you sure you want to log out?", "Log out", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
            SystemHistory.Log($"Signed out: {userName} ({role}).");
            LoggedOut = true; Close();
        };
        content.Dock = DockStyle.Fill; content.Padding = new Padding(32, 24, 32, 25); main.Controls.Add(content); content.BringToFront();
    }
    private void ShowPage(string page)
    {
        currentPage = page; pageTitle.Text = page; content.Controls.Clear();
        foreach (var button in navigationButtons)
        {
            var selected = string.Equals((string?)button.Tag, page, StringComparison.OrdinalIgnoreCase);
            button.BackColor = selected ? Color.FromArgb(218, 232, 253) : Color.FromArgb(242, 246, 252);
            button.ForeColor = selected ? Color.FromArgb(25, 76, 166) : Color.FromArgb(55, 70, 94);
            button.FlatAppearance.MouseOverBackColor = selected ? Color.FromArgb(218, 232, 253) : Color.FromArgb(229, 237, 249);
        }
        switch (page)
        {
            case "Overview": BuildDashboard(); break;
            case "New request": BuildNewTicket(); break;
            case "Knowledge base": BuildKnowledge(); break;
            case "Activity history": BuildActivityHistory(); break;
            case "Archived tickets":
            case "All tickets":
            case "My tickets": BuildTicketList(page); break;
        }
    }
    private void BuildDashboard()
    {
        var tickets = GetVisibleTickets();
        var pageWidth = Math.Max(640, content.ClientSize.Width - 64);
        var metricWidth = (pageWidth - 36) / 3;
        var open = tickets.Count(t => t.Status == "Open"); var progress = tickets.Count(t => t.Status == "In Progress"); var resolved = tickets.Count(t => t.Status == "Resolved");
        var urgent = tickets.Count(t => t.Priority == "Urgent" && t.Status != "Resolved");
        var hero = new Panel { Location = new Point(32, 8), Size = new Size(pageWidth, 126), BackColor = Color.FromArgb(226, 237, 253), Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right };
        content.Controls.Add(hero);
        hero.Controls.Add(new Label { Text = role == "IT Support" ? "Your service desk at a glance" : "Your IT, taken care of.", Location = new Point(24, 19), AutoSize = true, ForeColor = Navy, Font = new Font("Segoe UI Semibold", 19) });
        hero.Controls.Add(new Label { Text = role == "IT Support" ? $"{open} open requests  ·  {progress} being worked on  ·  {urgent} urgent" : "See updates, follow your requests, or tell us what you need help with.", Location = new Point(26, 59), AutoSize = true, ForeColor = Color.FromArgb(65, 83, 110), Font = new Font("Segoe UI", 10) });
        if (role == "Employee" && !string.IsNullOrWhiteSpace(department)) hero.Controls.Add(new Label { Text = "DEPARTMENT  ·  " + department.ToUpperInvariant(), Location = new Point(26, 91), AutoSize = true, ForeColor = Blue, Font = new Font("Segoe UI Semibold", 8) });
        var heroAction = new Button { Text = role == "IT Support" ? "View all tickets   →" : "＋   Create a request", Size = new Size(194, 42), Anchor = AnchorStyles.Top | AnchorStyles.Right, Location = new Point(pageWidth - 218, 42), BackColor = Color.FromArgb(69, 132, 238), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI Semibold", 9), Cursor = Cursors.Hand };
        heroAction.FlatAppearance.BorderSize = 0; hero.Controls.Add(heroAction); heroAction.Click += (_, _) => ShowPage(role == "IT Support" ? "All tickets" : "New request");

        int x = 32;
        var metrics = role == "IT Support"
            ? new[] { ("Open requests", open.ToString("00"), Color.FromArgb(233, 154, 50), "Awaiting support"), ("In progress", progress.ToString("00"), Blue, "Being handled"), ("Urgent", urgent.ToString("00"), Color.FromArgb(218, 86, 91), "Needs quick attention") }
            : new[] { ("Open", open.ToString("00"), Color.FromArgb(233, 154, 50), "Waiting for support"), ("In progress", progress.ToString("00"), Blue, "Being worked on"), ("Resolved", resolved.ToString("00"), Color.FromArgb(42, 160, 119), "Successfully completed") };
        foreach (var (label, value, accent, detail) in metrics) { AddStat(label, value, accent, detail, new Point(x, 151), new Size(metricWidth, 112)); x += metricWidth + 18; }
        var recentTitle = new Label { Text = role == "IT Support" ? "Latest requests" : "Your recent requests", Location = new Point(34, 285), AutoSize = true, Font = new Font("Segoe UI Semibold", 14), ForeColor = Navy }; content.Controls.Add(recentTitle);
        var viewAll = new LinkLabel { Text = role == "IT Support" ? "Manage tickets  →" : "View all requests  →", Location = new Point(pageWidth - 128, 289), AutoSize = true, LinkColor = Blue, Anchor = AnchorStyles.Top | AnchorStyles.Right, Font = new Font("Segoe UI Semibold", 9) }; viewAll.Click += (_, _) => ShowPage(role == "IT Support" ? "All tickets" : "My tickets"); content.Controls.Add(viewAll);
        SetupGrid(new Point(32, 318), new Size(pageWidth, 260));
        grid.DataSource = null; grid.DataSource = tickets.OrderByDescending(t => t.CreatedAt).Take(5).Select(t => role == "IT Support"
            ? new { Ticket = $"#{t.Id}", t.Title, t.Category, t.Priority, t.Status, Requester = t.Requester, Date = t.CreatedAt.ToString("MMM d") }
            : new { Ticket = $"#{t.Id}", t.Title, t.Category, t.Priority, t.Status, Requester = "", Date = t.CreatedAt.ToString("MMM d") }).ToList();
        if (grid.Columns["Requester"] is DataGridViewColumn requesterColumn) requesterColumn.Visible = role == "IT Support";
    }
    private void AddStat(string title, string value, Color accent, string detail, Point p, Size size)
    {
        var card = new Panel { Location = p, Size = size, BackColor = Color.White, BorderStyle = BorderStyle.FixedSingle }; content.Controls.Add(card);
        card.Controls.Add(new Panel { Location = new Point(0, 0), Size = new Size(4, size.Height), BackColor = accent });
        card.Controls.Add(new Label { Text = title.ToUpperInvariant(), Location = new Point(20, 15), AutoSize = true, ForeColor = Muted, Font = new Font("Segoe UI Semibold", 8) });
        card.Controls.Add(new Label { Text = value, Location = new Point(18, 34), AutoSize = true, ForeColor = Navy, Font = new Font("Segoe UI Semibold", 27) });
        card.Controls.Add(new Label { Text = detail, Location = new Point(20, 82), AutoSize = true, ForeColor = Muted, Font = new Font("Segoe UI", 8.5f) });
    }
    private void BuildTicketList(string page)
    {
        var pageWidth = Math.Max(640, content.ClientSize.Width - 64);
        content.Controls.Add(new Label { Text = page == "My tickets" ? "Requests you have submitted." : page == "Archived tickets" ? "Archived records are retained here for management reporting." : "Track and manage every support request.", Location = new Point(34, 1), AutoSize = true, ForeColor = Muted });
        var allVisible = (page == "Archived tickets" ? TicketStore.Tickets.Where(t => t.IsArchived) : GetVisibleTickets()).ToList();
        var summary = new[] { ("OPEN", allVisible.Count(t => t.Status == "Open"), Color.FromArgb(225, 157, 57)), ("IN PROGRESS", allVisible.Count(t => t.Status == "In Progress"), Blue), ("RESOLVED", allVisible.Count(t => t.Status == "Resolved"), Color.FromArgb(42, 160, 119)) };
        var cardWidth = (pageWidth - 36) / 3; var cardX = 32;
        foreach (var (label, value, accent) in summary)
        {
            var card = new Panel { Location = new Point(cardX, 34), Size = new Size(cardWidth, 82), BackColor = Color.White, BorderStyle = BorderStyle.FixedSingle };
            card.Controls.Add(new Panel { Location = new Point(0, 0), Size = new Size(4, 82), BackColor = accent });
            card.Controls.Add(new Label { Text = label, Location = new Point(16, 12), AutoSize = true, ForeColor = Muted, Font = new Font("Segoe UI Semibold", 8) });
            card.Controls.Add(new Label { Text = value.ToString("00"), Location = new Point(15, 30), AutoSize = true, ForeColor = Navy, Font = new Font("Segoe UI Semibold", 22) });
            content.Controls.Add(card); cardX += cardWidth + 18;
        }
        var search = new TextBox { PlaceholderText = "⌕  Search tickets…", Location = new Point(32, 132), Size = new Size(280, 38), Font = new Font("Segoe UI", 10), BorderStyle = BorderStyle.FixedSingle }; content.Controls.Add(search);
        var status = new ComboBox { Location = new Point(324, 132), Size = new Size(170, 38), DropDownStyle = ComboBoxStyle.DropDownList, Font = new Font("Segoe UI", 9) }; status.Items.AddRange(["All statuses", "Open", "In Progress", "Resolved"]); status.SelectedIndex = 0; content.Controls.Add(status);
        var toolbarButtonWidth = 78;
        const int toolbarGap = 8;
        if (role == "IT Support")
        {
            var supportActions = page == "All tickets" ? 3 : 1;
            if (page == "Archived tickets")
            {
                var restore = new Button { Text = "Restore", Location = new Point(pageWidth - toolbarButtonWidth, 131), Size = new Size(toolbarButtonWidth, 40), BackColor = Blue, ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI Semibold", 8.5f), Cursor = Cursors.Hand, Anchor = AnchorStyles.Top | AnchorStyles.Right };
                restore.FlatAppearance.BorderSize = 0; restore.FlatAppearance.MouseOverBackColor = Color.FromArgb(36, 95, 202); content.Controls.Add(restore);
                restore.Click += (_, _) => RestoreSelectedTickets();
            }
            else
            {
                var update = new Button { Text = "Update", Location = new Point(pageWidth - toolbarButtonWidth * supportActions - toolbarGap * (supportActions - 1), 131), Size = new Size(toolbarButtonWidth, 40), BackColor = Blue, ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI Semibold", 8), Cursor = Cursors.Hand, Anchor = AnchorStyles.Top | AnchorStyles.Right };
                update.FlatAppearance.BorderSize = 0; update.FlatAppearance.MouseOverBackColor = Color.FromArgb(36, 95, 202); content.Controls.Add(update);
                update.Click += (_, _) => UpdateSelectedTicket();
            }
            if (page == "All tickets")
            {
                var selectAll = new Button { Text = "Select all", Location = new Point(pageWidth - toolbarButtonWidth * 2 - toolbarGap, 131), Size = new Size(toolbarButtonWidth, 40), BackColor = Color.FromArgb(226, 237, 253), ForeColor = Navy, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI Semibold", 8), Cursor = Cursors.Hand, Anchor = AnchorStyles.Top | AnchorStyles.Right };
                selectAll.FlatAppearance.BorderColor = Color.FromArgb(205, 219, 239); selectAll.FlatAppearance.MouseOverBackColor = Color.FromArgb(213, 228, 250); content.Controls.Add(selectAll);
                selectAll.Click += (_, _) =>
                {
                    if (grid.Rows.Count == 0) return;
                    if (grid.SelectedRows.Count == grid.Rows.Count) { grid.ClearSelection(); selectAll.Text = "Select all"; }
                    else { grid.SelectAll(); selectAll.Text = "Clear sel."; }
                };
                var archive = new Button { Text = "Archive", Location = new Point(pageWidth - toolbarButtonWidth, 131), Size = new Size(toolbarButtonWidth, 40), BackColor = Color.FromArgb(66, 91, 130), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI Semibold", 8.5f), Cursor = Cursors.Hand, Anchor = AnchorStyles.Top | AnchorStyles.Right };
                archive.FlatAppearance.BorderSize = 0; archive.FlatAppearance.MouseOverBackColor = Color.FromArgb(48, 70, 105); content.Controls.Add(archive);
                archive.Click += (_, _) => ArchiveSelectedTickets();
            }
        }
        SetupGrid(new Point(32, 187), new Size(pageWidth, Math.Max(240, content.ClientSize.Height - 220)));
        void RefreshGrid()
        {
            IEnumerable<Ticket> items = page == "Archived tickets" ? TicketStore.Tickets.Where(t => t.IsArchived) : GetVisibleTickets();
            if (page == "My tickets") items = items.Where(t => t.Requester.Equals(userName, StringComparison.OrdinalIgnoreCase));
            if (status.SelectedIndex > 0) items = items.Where(t => t.Status == status.Text);
            items = items.Where(t => (t.Title + t.Category + t.Requester + t.AssignedTo + t.Id).Contains(search.Text, StringComparison.OrdinalIgnoreCase));
            grid.DataSource = null; grid.DataSource = items.OrderByDescending(t => t.CreatedAt).Select(t => new { Ticket = $"#{t.Id}", t.Title, t.Category, t.Priority, t.Status, t.Requester, Assigned = t.AssignedTo, Created = t.CreatedAt.ToString("MMM d, yyyy"), Archived = t.IsArchived ? t.ArchivedAt?.ToString("MMM d, yyyy") : "" }).ToList();
            if (grid.Columns["Archived"] is DataGridViewColumn archivedColumn) archivedColumn.Visible = page == "Archived tickets";
        }
        search.TextChanged += (_, _) => RefreshGrid(); status.SelectedIndexChanged += (_, _) => RefreshGrid(); RefreshGrid();
    }
    private static void FormatTicketCell(object? sender, DataGridViewCellFormattingEventArgs e)
    {
        if (sender is not DataGridView table || e.RowIndex < 0 || e.Value is null) return;
        var column = table.Columns[e.ColumnIndex].Name;
        if (column == "Status")
        {
            e.CellStyle.Font = new Font("Segoe UI Semibold", 8.5f);
            e.CellStyle.ForeColor = e.Value.ToString() switch { "Open" => Color.FromArgb(184, 117, 24), "In Progress" => Color.FromArgb(46, 111, 225), "Resolved" => Color.FromArgb(31, 139, 101), _ => Muted };
        }
        else if (column == "Priority")
        {
            e.CellStyle.Font = new Font("Segoe UI Semibold", 8.5f);
            e.CellStyle.ForeColor = e.Value.ToString() switch { "Urgent" => Color.FromArgb(194, 57, 64), "High" => Color.FromArgb(205, 116, 35), _ => Color.FromArgb(70, 84, 104) };
        }
    }
    private void SetupGrid(Point p, Size size)
    {
        grid.DataSource = null; grid.Location = p; grid.Size = size; grid.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom; grid.BackgroundColor = Color.White; grid.BorderStyle = BorderStyle.None; grid.GridColor = Color.FromArgb(235, 239, 245); grid.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal; grid.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None; grid.RowHeadersVisible = false; grid.AllowUserToAddRows = false; grid.AllowUserToDeleteRows = false; grid.ReadOnly = true; grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect; grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill; grid.RowTemplate.Height = 42; grid.ColumnHeadersHeight = 42; grid.EnableHeadersVisualStyles = false; grid.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(247, 249, 252); grid.ColumnHeadersDefaultCellStyle.ForeColor = Muted; grid.ColumnHeadersDefaultCellStyle.SelectionBackColor = Color.FromArgb(247, 249, 252); grid.ColumnHeadersDefaultCellStyle.SelectionForeColor = Muted; grid.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI Semibold", 9); grid.DefaultCellStyle.Font = new Font("Segoe UI", 9); grid.DefaultCellStyle.ForeColor = Color.FromArgb(54, 66, 84); grid.DefaultCellStyle.SelectionBackColor = Color.FromArgb(232, 240, 253); grid.DefaultCellStyle.SelectionForeColor = Navy; content.Controls.Add(grid);
    }
    private void BuildNewTicket()
    {
        content.Controls.Add(new Label { Text = "Tell us what’s going on and we’ll get you back on track.", Location = new Point(34, 1), AutoSize = true, ForeColor = Muted });
        var card = new Panel { Location = new Point(32, 38), Size = new Size(680, 500), BackColor = Color.White, BorderStyle = BorderStyle.FixedSingle }; content.Controls.Add(card);
        AddField(card, "SUBJECT", new TextBox { PlaceholderText = "Briefly describe the issue" }, 24, 35, 610, 36, out var subject);
        var cat = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList }; cat.Items.AddRange(["Hardware", "Software", "Network", "Access", "Email", "Other"]); cat.SelectedIndex = 0; AddField(card, "CATEGORY", cat, 24, 120, 290, 36, out _);
        var priority = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList }; priority.Items.AddRange(["Low", "Medium", "High", "Urgent"]); priority.SelectedIndex = 1; AddField(card, "PRIORITY", priority, 344, 120, 290, 36, out _);
        var desc = new TextBox { Multiline = true, ScrollBars = ScrollBars.Vertical, PlaceholderText = "Include any details that could help us solve this…" }; AddField(card, "DESCRIPTION", desc, 24, 205, 610, 130, out _);
        var submit = new Button { Text = "Submit request   →", Location = new Point(24, 390), Size = new Size(190, 44), BackColor = Blue, ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI Semibold", 9.5f) }; submit.FlatAppearance.BorderSize = 0; card.Controls.Add(submit);
        submit.Click += (_, _) =>
        {
            if (string.IsNullOrWhiteSpace(subject.Text) || string.IsNullOrWhiteSpace(desc.Text)) { MessageBox.Show("Please enter a subject and description.", "A little more detail", MessageBoxButtons.OK, MessageBoxIcon.Information); return; }
            var ticket = new Ticket { Id = TicketStore.Tickets.Count == 0 ? 1001 : TicketStore.Tickets.Max(t => t.Id) + 1, Title = subject.Text.Trim(), Category = cat.Text, Priority = priority.Text, Requester = userName, Description = desc.Text.Trim() };
            TicketStore.Tickets.Add(ticket); TicketStore.Save();
            SystemHistory.Log($"Ticket #{ticket.Id} created by {userName}; category: {ticket.Category}; priority: {ticket.Priority}.");
            MessageBox.Show("Your request has been submitted.", "Ticket created", MessageBoxButtons.OK, MessageBoxIcon.Information); ShowPage("My tickets");
        };
    }
    private static void AddField(Control parent, string label, Control field, int x, int y, int width, int height, out TextBox textBox)
    {
        parent.Controls.Add(new Label { Text = label, Location = new Point(x, y), AutoSize = true, ForeColor = Muted, Font = new Font("Segoe UI Semibold", 8) }); field.Location = new Point(x, y + 22); field.Size = new Size(width, height); field.Font = new Font("Segoe UI", 10); if (field is TextBox t) { t.BorderStyle = BorderStyle.FixedSingle; textBox = t; } else textBox = new TextBox(); parent.Controls.Add(field);
    }
    private void BuildKnowledge()
    {
        content.Controls.Add(new Label { Text = "Quick answers to common IT questions.", Location = new Point(34, 1), AutoSize = true, ForeColor = Muted });
        var tips = new[] { ("Connect to office Wi-Fi", "Select NORTHSTAR-STAFF and sign in with your work account. If prompted, accept the security certificate."), ("Reset your password", "Use the password reset link on the company sign-in page. Contact IT if you no longer have access to your recovery method."), ("Set up a new printer", "Open Settings → Bluetooth & devices → Printers & scanners, then choose Add device while connected to the office network."), ("Request software access", "Submit a ticket under the Access category and include the application name and your manager’s approval.") };
        int y = 42; foreach (var (title, body) in tips) { var card = new Panel { Location = new Point(32, y), Size = new Size(850, 92), BackColor = Color.White, BorderStyle = BorderStyle.FixedSingle }; card.Controls.Add(new Label { Text = title, Location = new Point(20, 15), AutoSize = true, ForeColor = Navy, Font = new Font("Segoe UI Semibold", 11) }); card.Controls.Add(new Label { Text = body, Location = new Point(20, 43), Size = new Size(790, 38), ForeColor = Muted }); content.Controls.Add(card); y += 105; }
    }
    private void BuildActivityHistory()
    {
        content.Controls.Add(new Label { Text = "Review account and ticket activity recorded by the system.", Location = new Point(34, 1), AutoSize = true, ForeColor = Muted });
        var pageWidth = Math.Max(640, content.ClientSize.Width - 64);
        var note = new Panel { Location = new Point(32, 34), Size = new Size(pageWidth, 66), BackColor = Color.FromArgb(226, 237, 253), Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right };
        note.Controls.Add(new Label { Text = "READ-ONLY ACTIVITY LOG", Location = new Point(18, 11), AutoSize = true, ForeColor = Navy, Font = new Font("Segoe UI Semibold", 9) });
        note.Controls.Add(new Label { Text = "Entries cannot be deleted from this screen. Passwords are not recorded.", Location = new Point(18, 34), AutoSize = true, ForeColor = Color.FromArgb(65, 83, 110), Font = new Font("Segoe UI", 9) });
        content.Controls.Add(note);
        SetupGrid(new Point(32, 116), new Size(pageWidth, Math.Max(240, content.ClientSize.Height - 148)));
        grid.DataSource = null;
        grid.DataSource = SystemHistory.ReadEntries().AsEnumerable().Reverse().Select(entry => new { entry.Timestamp, entry.Activity }).ToList();
        if (grid.Columns["Timestamp"] is DataGridViewColumn timeColumn) timeColumn.FillWeight = 27;
        if (grid.Columns["Activity"] is DataGridViewColumn activityColumn) activityColumn.FillWeight = 73;
    }
    private IEnumerable<Ticket> GetVisibleTickets() => role == "IT Support"
        ? TicketStore.Tickets.Where(t => !t.IsArchived)
        : TicketStore.Tickets.Where(t => !t.IsArchived && t.Requester.Equals(userName, StringComparison.OrdinalIgnoreCase));
    private void UpdateSelectedTicket()
    {
        if (grid.SelectedRows.Count != 1) { MessageBox.Show("Select exactly one ticket row to update."); return; }
        var raw = grid.SelectedRows[0].Cells[0].Value?.ToString()?.TrimStart('#'); if (!int.TryParse(raw, out var id)) return;
        var ticket = TicketStore.Tickets.FirstOrDefault(t => t.Id == id); if (ticket == null) return;
        var oldStatus = ticket.Status;
        var oldAssignee = ticket.AssignedTo;
        using var dialog = new TicketUpdateForm(ticket);
        if (dialog.ShowDialog(this) == DialogResult.OK)
        {
            TicketStore.Save();
            SystemHistory.Log($"Ticket #{ticket.Id} updated by {userName}; status: {oldStatus} -> {ticket.Status}; assigned to: {oldAssignee} -> {ticket.AssignedTo}.");
            ShowPage(currentPage);
        }
    }
    private void ArchiveSelectedTickets()
    {
        if (role != "IT Support" || currentPage != "All tickets") return;
        var selectedIds = grid.SelectedRows.Cast<DataGridViewRow>()
            .Select(row => row.Cells[0].Value?.ToString()?.TrimStart('#'))
            .Where(value => int.TryParse(value, out _))
            .Select(value => int.Parse(value!))
            .Distinct()
            .ToHashSet();
        if (selectedIds.Count == 0) { MessageBox.Show("Select one or more ticket rows first."); return; }
        var result = MessageBox.Show($"Archive {selectedIds.Count} selected ticket(s)?\n\nThey will be kept in the system and listed under Archived tickets for reporting.", "Archive tickets", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
        if (result != DialogResult.Yes) return;
        var archivedIds = TicketStore.Tickets.Where(ticket => selectedIds.Contains(ticket.Id) && !ticket.IsArchived).Select(ticket => ticket.Id).ToList();
        foreach (var ticket in TicketStore.Tickets.Where(ticket => selectedIds.Contains(ticket.Id)))
        {
            ticket.IsArchived = true;
            ticket.ArchivedAt = DateTime.Now;
            ticket.ArchivedBy = userName;
        }
        TicketStore.Save();
        SystemHistory.Log($"Ticket(s) {string.Join(", #", archivedIds)} archived by IT Support user {userName}.");
        ShowPage(currentPage);
    }
    private void RestoreSelectedTickets()
    {
        if (role != "IT Support" || currentPage != "Archived tickets") return;
        var selectedIds = grid.SelectedRows.Cast<DataGridViewRow>()
            .Select(row => row.Cells[0].Value?.ToString()?.TrimStart('#'))
            .Where(value => int.TryParse(value, out _))
            .Select(value => int.Parse(value!))
            .Distinct()
            .ToHashSet();
        if (selectedIds.Count == 0) { MessageBox.Show("Select one or more archived ticket rows first."); return; }
        var result = MessageBox.Show($"Restore {selectedIds.Count} selected ticket(s) to All tickets?\n\nThey will be active again and can be archived later.", "Restore tickets", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
        if (result != DialogResult.Yes) return;
        var restoredIds = TicketStore.Tickets.Where(ticket => selectedIds.Contains(ticket.Id) && ticket.IsArchived).Select(ticket => ticket.Id).ToList();
        foreach (var ticket in TicketStore.Tickets.Where(ticket => selectedIds.Contains(ticket.Id)))
        {
            ticket.IsArchived = false;
            ticket.ArchivedAt = null;
            ticket.ArchivedBy = "";
        }
        TicketStore.Save();
        SystemHistory.Log($"Ticket(s) {string.Join(", #", restoredIds)} restored from archive by IT Support user {userName}.");
        ShowPage(currentPage);
    }
}
